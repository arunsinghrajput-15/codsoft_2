
# 📃PORTFOLIO

1) This is a  **CSS,HTML and Javascript**.

2) It has an interactive interface and has columns, divide sections,headers and footers.


## Demo

https://coder-rajora.github.io/CODESOFT-TASK-2-PORTFOLIO/
## Screenshots


1)  Header Section 

![r1](https://github.com/coder-rajora/CODESOFT-TASK-2-PORTFOLIO/assets/91421022/7528a157-00e7-4293-8607-861f411de8bd)

2) Skill Section

![r2](https://github.com/coder-rajora/CODESOFT-TASK-2-PORTFOLIO/assets/91421022/63ec4dc7-64e4-42fe-8c87-d808a03d5791)

3) Education Section

![r3](https://github.com/coder-rajora/CODESOFT-TASK-2-PORTFOLIO/assets/91421022/e2fe02f0-8548-4804-8b5d-240769a886d0)

4) Project Section

![r4](https://github.com/coder-rajora/CODESOFT-TASK-2-PORTFOLIO/assets/91421022/d6327028-924c-452e-bceb-12190749381a)


5) Footer Section 


![r5](https://github.com/coder-rajora/CODESOFT-TASK-2-PORTFOLIO/assets/91421022/30ce7347-49b4-438e-b989-af136a828a6f)



## Author

- [Rishabh Rajora](https://github.com/coder-rajora)

